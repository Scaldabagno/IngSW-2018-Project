package javasql;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Francesco
 */
public class JavaSQL {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        SQLManager sqlm = new SQLManager("<DBMS-HOST", "<DBMS-USERNAME>", "<DBMS-USER-PASSWORD>", "<DB-NAME>");
        if (sqlm.connect()) {
            System.out.println("Connected.");
            try {
                sqlm.executeQuery("Select * from members;");
                while (sqlm.getResultSet().next()) {
                    System.out.print(sqlm.getResultSet().getString("name"));
                    System.out.println(" "+sqlm.getResultSet().getString("surname"));
                    System.out.println("\t"+sqlm.getResultSet().getString("level"));
                    System.out.println("\t"+sqlm.getResultSet().getString("pemail"));
                }
                if (sqlm.disconnect()) {
                    System.out.println("Disconnected.");
                }
            } catch (SQLException ex) {
                Logger.getLogger(JavaSQL.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            System.out.println("Could not connect.");
        }
    }
}
